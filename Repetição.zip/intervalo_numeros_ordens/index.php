<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Intervalo de números</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>
	<main>
		<h1>Intervalo de números</h1>
		<section>
			<form action="resultado.php" method="post">
				<label for="intInicial"><strong>Digite o valor inicial</strong></label><br>
				<input type="number" min="0" name="intInicial" id="intInicial" />
				<label for="intFinal"><strong>Digite o valor final</strong></label><br>
				<input type="number" min="0" name="intFinal" id="intFinal" />
				<input type="submit" value="Enviar">
			</form>
		</section>
	</main>
</body>

</html>