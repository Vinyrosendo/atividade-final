<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Resultado</title>
	<link rel="Stylesheet" href="style.css">
</head>

<body>
	<main>
		<h1>Resultado:</h1>
		<section>
			<?php
				$inicio = $_REQUEST['intInicial'];
				$fim = $_REQUEST['intFinal'];

				if ($inicio < $fim) {
					// Se o número de início for menor que o número de fim, imprime em ordem crescente
					for ($i = $inicio; $i <= $fim; $i++) {
						echo "<p>$i</p>";
					}
				} else {
					// Se o número de início for maior que o número de fim, imprime em ordem decrescente
					for ($i = $inicio; $i >= $fim; $i--) {
						echo "<p>$i</p>";
					}
				}


			?>

		</section>
		<button onclick="javascript:window.location.href='index.php'">
			&#x2B05; Voltar
		</button>
	</main>
</body>

</html>