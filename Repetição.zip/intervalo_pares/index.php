<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Resultado</title>
	<link rel="Stylesheet" href="style.css">
</head>

<body>
	<main>
		<h1>Resultado:</h1>
		<section>
			<?php
				$soma = 0;
				
				for ($numero = 10; $numero <= 500; $numero++) {
					if ($numero % 2 == 0) {
						$soma += $numero;
					}
				}

				echo "A soma dos números pares no intervalo de 10 a 500 é: " . $soma;

			?>

		</section>
	</main>
</body>

</html>