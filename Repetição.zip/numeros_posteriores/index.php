<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Números posteriores</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>
	<main>
		<h1>Números posteriores</h1>
		<section>
			<form action="resultado.php" method="post">
				<label for="intNumero"><strong>Digite um número</strong></label><br>
				<input type="number" min="0" name="intNumero" id="intNumero" />
				<input type="submit" value="Enviar">
			</form>
		</section>
	</main>
</body>

</html>