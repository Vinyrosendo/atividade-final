<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
	<title>Repetição</title>
</head>

<body>
	<main>
		<header>
			<a href="index.php">Index</a>
			<a href="tabuada_do_sete/index.php">Tabuada do 7</a>
			<a href="resultados_tabuada_do_sete/index.php">resultados da tabuada do 7</a>
			<a href="tabuada/index.php">Tabuada</a>
		</header>
	</main>
</body>

</html>