<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Resultado</title>
	<link rel="Stylesheet" href="style.css">
</head>

<body>
	<main>
		<h1>Resultado:</h1>
		<section>
			<?php
				for ($i=0; $i <= 10; $i++) { 
					echo "<p>7 * $i = " . 7 * $i . "</p>";
				}
			?>

		</section>
	</main>
</body>

</html>